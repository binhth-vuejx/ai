---
name: svelte-component-builder
description: Chuyên gia xây dựng component Svelte 5 dựa trên thiết kế chuẩn từ file .pen. Sử dụng khi cần phân tích ảnh thiết kế, cập nhật System Design trong file .pen, và sinh mã nguồn Svelte 5 (Shadcn UI + Tailwind) theo quy hoạch thư mục chuẩn.
---

# Quy trình xây dựng Component Svelte 5 chuẩn Pixel-Perfect

Kỹ năng này định nghĩa quy trình 4 bước để chuyển đổi từ ý tưởng/hình ảnh sang một component Svelte 5 hoàn thiện và có tài liệu.

## 1. Phân tích & Thiết kế (.pen)
Khi nhận yêu cầu hoặc hình ảnh, phải cập nhật file thiết kế `.pen` trước:
- **System Design:** Luôn chèn hoặc cập nhật Component vào khung chứa System Design của dự án (thường là Node ID `MzSDs`).
- **Độ chính xác 1:1:** Thiết kế phải khớp từng pixel với ảnh mẫu (Padding, Gap, Sizing).
- **Màu sắc:** 
    - Cưỡng bức Light Mode (Nền trắng `#FFFFFF`, chữ đen).
    - Màu Border mặc định: `#dddddd`.
- **Biểu tượng:** Sử dụng `icon_font` (thư viện `lucide`) thay vì vẽ path thủ công để đảm bảo căn giữa tuyệt đối trong các nút/checkbox.
- **Reusable:** Đánh dấu `reusable: true` cho component chính.

## 2. Quy hoạch thư mục (Directory Structure)
Mọi component mới phải được tổ chức theo cấu trúc:
```
src/lib/components/[ComponentName]/
├── index.svelte           # Mã nguồn Svelte 5
└── walkthrough.md         # Tài liệu hướng dẫn thiết kế
```

## 3. Tiêu chuẩn Mã nguồn (Svelte 5)
- **Framework:** Svelte 5 (Sử dụng Runes: `$props`, `$state`).
- **Thành phần UI:** Sử dụng Shadcn-svelte làm nền tảng (import từ `$lib/components/ui/...`).
- **Ghi đè Style (Critical):** 
    - Luôn ghi đè (override) các padding, gap, margin mặc định của Shadcn bằng Tailwind (`p-0`, `m-0`, `gap-0`) để khớp 1:1 với thiết kế Pen.
    - KHÔNG để framework tự tạo khoảng trắng dư thừa.
- **Tính tương tác (Reactivity):**
    - Sử dụng Object/Record (`$state<Record<string, boolean>>({})`) để quản lý trạng thái chọn thay vì `Set`.
    - Ép màu nền Active bằng class điều kiện rõ ràng: `{selected ? 'bg-[#FFFBE6]' : 'bg-white'}`.
- **Theme:** Thêm `style="color-scheme: light;"` và class `text-black` vào root div để chống lại Dark mode của hệ thống.
- **Icon:** Sử dụng thư viện `lucide-svelte`. Tuyệt đối KHÔNG dùng `lucide-react`.

## 4. Tài liệu (Walkthrough)
File `walkthrough.md` nằm cạnh `index.svelte` phải chứa:
- Node ID của thiết kế trong file `.pen`.
- Bảng mã màu HEX đã sử dụng.
- Thông số Padding/Margin chuẩn.
- Các trạng thái (Default, Selected, Hover).

## Công cụ hỗ trợ
- Sử dụng `pencil` tools để cập nhật file `.pen`.
- Sử dụng `write_file` để sinh mã nguồn và tài liệu.
- Sử dụng `run_shell_command` với `node -e` hoặc `jq` nếu cần can thiệp sâu vào JSON của file `.pen`.
