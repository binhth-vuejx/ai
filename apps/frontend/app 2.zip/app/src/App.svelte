<script lang="ts">
  import { KhuBaoTonPage, Sonner } from "@/components/ui/index.js";
  import ProvincePicker from "$lib/components/ProvincePicker.svelte";
</script>

<Sonner />

<div class="app-container flex min-h-screen w-full overflow-hidden">
    <ProvincePicker />
</div>

<style>
  :global(body) {
    margin: 0;
    padding: 0;
  }
  .app-container {
    height: 100vh;
    width: 100vw;
  }
</style>
