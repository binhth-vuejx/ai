<script lang="ts">
  import { Badge } from "@/components/ui/badge/index.js";
  import { Button } from "@/components/ui/button/index.js";
  import * as Card from "@/components/ui/card/index.js";
  import { Input } from "@/components/ui/input/index.js";
  import { Checkbox } from "@/components/ui/checkbox/index.js";
  import * as Table from "@/components/ui/table/index.js";
  import * as Pagination from "@/components/ui/pagination/index.js";
  import * as Dialog from "@/components/ui/dialog/index.js";
  import { toast } from "svelte-sonner";
  import {
    Plus,
    Search,
    SlidersHorizontal,
    FileDown,
    ChevronUp,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    PencilLine,
    Trash2,
    Check
  } from "lucide-svelte";
  import { client } from "@/utils/trpc";
  import { onMount } from "svelte";

  // Mock data for sidebar filters
  const filterSections = [
    {
      title: "Loại hình khu bảo tồn",
      items: [
        { label: "Vườn quốc gia", count: 35 },
        { label: "Khu dự trữ thiên nhiên", count: 61 },
        { label: "Khu bảo vệ cảnh quan", count: 63 },
        { label: "Khu bảo tồn loài - sinh cảnh", count: 29 }
      ]
    },
    {
      title: "Tỉnh/Thành phố",
      items: [
        { label: "Tỉnh An Giang", count: 24 },
        { label: "Tỉnh Bắc Ninh", count: 2 }
      ],
      pagination: "Trang 1/7"
    },
    {
      title: "Tình trạng quy hoạch",
      items: [
        { label: "Chuyển tiếp", count: 177 },
        { label: "Sẽ chuyển hạng", count: 0 },
        { label: "Sẽ thành lập mới", count: 10 }
      ]
    },
    {
      title: "Phạm vi",
      items: [
        { label: "Khu bảo tồn biển", count: 1 },
        { label: "Khu bảo tồn trên đất liền", count: 178 },
        { label: "Khu bảo tồn ven biển", count: 1 }
      ]
    }
  ];

  // Table state
  let natureReserves = $state<any[]>([]);
  let isLoading = $state(true);
  let searchQuery = $state("");

  // Export state
  let isExportDialogOpen = $state(false);
  let exportColumns = $state([
    { id: "stt", label: "STT", checked: true },
    { id: "name", label: "Khu bảo tồn thiên nhiên", checked: true },
    { id: "type", label: "Loại hình khu bảo tồn", checked: true },
    { id: "location", label: "Tỉnh/Thành phố", checked: true },
    { id: "status", label: "Cấp di sản thiên nhiên", checked: true },
    { id: "area", label: "Tổng diện tích (ha)", checked: true }
  ]);

  function handleExport() {
    const selected = exportColumns.filter(c => c.checked).map(c => c.label);
    if (selected.length === 0) {
      toast.error("Vui lòng chọn ít nhất một cột để xuất.");
      return;
    }
    toast.success(`Đang chuẩn bị xuất file với ${selected.length} cột dữ liệu...`);
    setTimeout(() => {
      isExportDialogOpen = false;
    }, 500);
  }

  // Fetch data on mount
  onMount(async () => {
    try {
      isLoading = true;
      const result = await client.s1.getUsers.query();
      // Map getUsers data to Nature Reserve structure for demo/request
      natureReserves = result.users.map((user: any, index: number) => ({
        id: index + 1,
        name: `Khu bảo tồn ${user.name}`,
        type: index % 2 === 0 ? "Vườn quốc gia" : "Khu dự trữ thiên nhiên",
        location: "Hà Nội",
        status: "Di sản thiên nhiên cấp quốc gia",
        area: (Math.random() * 10000).toFixed(2)
      }));
    } catch (error) {
      console.error("Failed to fetch users:", error);
    } finally {
      isLoading = false;
    }
  });
</script>

<div class="flex h-full w-full gap-6 bg-slate-50/50 p-6 font-sans">
  <!-- Left Sidebar Filters -->
  <aside class="flex w-72 flex-col gap-3 overflow-y-auto">
    {#each filterSections as section}
      <Card.Root class="overflow-hidden border-slate-200 bg-white shadow-sm">
        <header class="flex h-8 items-center justify-between bg-[#0B6237] px-3 font-semibold text-white">
          <span class="text-[11px]">{section.title}</span>
          <div class="flex items-center gap-1">
            <Search class="size-3" />
            <ChevronUp class="size-3" />
          </div>
        </header>
        <Card.Content class="p-0">
          <div class="flex flex-col">
            {#each section.items as item, index}
              <div
                class="flex items-center justify-between border-b border-slate-100 px-3 py-1 last:border-0"
              >
                <div class="flex items-center gap-2">
                  <Checkbox
                    id="filter-{section.title}-{index}"
                    class="size-3 border-slate-300"
                  />
                  <label
                    for="filter-{section.title}-{index}"
                    class="cursor-pointer text-[11px] text-slate-700 hover:text-slate-900"
                  >
                    {item.label}
                  </label>
                </div>
                <Badge
                  variant="outline"
                  class="h-4 rounded border-indigo-100 bg-indigo-50 px-1 py-0 text-[9px] font-medium text-slate-700 shadow-none"
                >
                  {item.count}
                </Badge>
              </div>
            {/each}
          </div>
          {#if section.pagination}
            <footer class="flex items-center justify-between bg-slate-50 px-3 py-1 text-[10px] text-slate-500">
              <ChevronLeft class="size-3 cursor-pointer hover:text-slate-700" />
              <span>{section.pagination}</span>
              <ChevronRight class="size-3 cursor-pointer hover:text-slate-700" />
            </footer>
          {/if}
        </Card.Content>
      </Card.Root>
    {/each}
  </aside>

  <!-- Main Content Area -->
  <main class="flex flex-1 flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
    <!-- Header Right Area -->
    <header class="flex items-center justify-between border-b border-slate-200">
      <div class="flex h-10 flex-1 items-center overflow-hidden">
        <div class="flex h-full shrink-0 items-center bg-[#0B6237] px-3">
          <h2 class="text-[12px] font-bold text-white">
            Khu bảo tồn thiên nhiên - Tổng số: {natureReserves.length}
          </h2>
        </div>
        <div class="flex h-full flex-1 items-center px-4">
          <Search class="mr-2 size-3.5 text-slate-400" />
          <input
            type="text"
            bind:value={searchQuery}
            placeholder="Tìm kiếm theo từ khoá..."
            class="flex-1 bg-transparent text-[12px] outline-none placeholder:text-slate-400"
          />
        </div>
      </div>
      <div class="flex items-center gap-1.5 px-3">
        <Button size="icon" class="size-6 rounded bg-[#0B6237] hover:bg-[#09502d]">
          <Search class="size-3" />
        </Button>
        <Button variant="outline" size="icon" class="size-6 rounded border-slate-200">
          <SlidersHorizontal class="size-3 text-slate-600" />
        </Button>
        <Button size="icon" class="size-6 rounded bg-[#0B6237] hover:bg-[#09502d]">
          <Plus class="size-3.5" />
        </Button>
        <Button 
          id="export-button"
          onclick={() => isExportDialogOpen = true}
          class="h-6 rounded bg-[#0B6237] px-2 font-semibold text-white hover:bg-[#09502d]"
        >
          <span class="text-[11px]">Xuất file</span>
        </Button>
      </div>
    </header>

    <Dialog.Root bind:open={isExportDialogOpen}>
      <Dialog.Content class="sm:max-w-[425px] bg-white">
        <Dialog.Header>
          <Dialog.Title class="text-[16px] font-bold text-[#0B6237]">Cấu hình xuất dữ liệu</Dialog.Title>
          <Dialog.Description class="text-[13px] text-slate-500">
            Chọn các cột dữ liệu bạn muốn bao gồm trong tệp xuất bản.
          </Dialog.Description>
        </Dialog.Header>
        <div class="grid gap-4 py-4">
          <div class="grid grid-cols-2 gap-y-3">
            {#each exportColumns as column}
              <div class="flex items-center space-x-2">
                <Checkbox id={column.id} bind:checked={column.checked} class="size-4" />
                <label
                  for={column.id}
                  class="cursor-pointer text-[13px] font-medium leading-none text-slate-700 hover:text-slate-900"
                >
                  {column.label}
                </label>
              </div>
            {/each}
          </div>
        </div>
        <Dialog.Footer class="gap-2 border-t border-slate-100 pt-4">
          <Button variant="outline" size="sm" onclick={() => isExportDialogOpen = false} class="h-8 text-[12px]">Hủy</Button>
          <Button size="sm" class="h-8 bg-[#0B6237] text-[12px] hover:bg-[#09502d]" onclick={handleExport}>Xuất file</Button>
        </Dialog.Footer>
      </Dialog.Content>
    </Dialog.Root>

    <!-- Table Container -->
    <div class="flex-1 overflow-auto">
      <Table.Root class="w-full">
        <Table.Header class="sticky top-0 z-10 bg-white">
          <Table.Row class="hover:bg-transparent">
            <Table.Head class="h-8 w-[40px] border-r border-slate-200 text-center text-[11px] font-bold text-[#0B6237]">STT</Table.Head>
            <Table.Head class="h-8 border-r border-slate-200 px-3 text-[11px] font-bold text-[#0B6237]">Khu bảo tồn thiên nhiên</Table.Head>
            <Table.Head class="h-8 w-[140px] border-r border-slate-200 text-center text-[11px] font-bold text-[#0B6237]">Loại hình khu bảo tồn</Table.Head>
            <Table.Head class="h-8 w-[100px] border-r border-slate-200 text-center text-[11px] font-bold text-[#0B6237]">Tỉnh/Thành phố</Table.Head>
            <Table.Head class="h-8 w-[180px] border-r border-slate-200 text-center text-[11px] font-bold text-[#0B6237]">Cấp di sản thiên nhiên</Table.Head>
            <Table.Head class="h-8 w-[100px] border-r border-slate-200 text-center text-[11px] font-bold text-[#0B6237]">Tổng diện tích (ha)</Table.Head>
            <Table.Head class="h-8 w-[60px] text-center text-[11px] font-bold text-[#0B6237]">Thao tác</Table.Head>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {#if isLoading}
            <Table.Row>
              <Table.Cell colspan={7} class="py-10 text-center text-slate-400">Đang tải dữ liệu...</Table.Cell>
            </Table.Row>
          {:else}
            {#each natureReserves as row, index}
              <Table.Row class="border-b border-slate-200 odd:bg-white even:bg-slate-50/30">
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-center text-[11px] text-slate-600">
                  {row.id}
                </Table.Cell>
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-[11px] font-medium text-slate-900">
                  {row.name}
                </Table.Cell>
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-center text-[11px] text-slate-600">
                  {row.type}
                </Table.Cell>
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-center text-[11px] text-slate-600">
                  {row.location}
                </Table.Cell>
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-center text-[11px] text-slate-600">
                  {row.status}
                </Table.Cell>
                <Table.Cell class="h-8 border-r border-slate-100 py-0.5 text-center text-[11px] text-slate-600">
                  {row.area}
                </Table.Cell>
                <Table.Cell class="h-8 py-0.5 text-center">
                  <div class="flex items-center justify-center gap-2">
                    <button class="text-[#0B6237] hover:text-[#09502d]">
                      <PencilLine class="size-3" />
                    </button>
                    <button class="text-red-500 hover:text-red-600">
                      <Trash2 class="size-3" />
                    </button>
                  </div>
                </Table.Cell>
              </Table.Row>
            {/each}
          {/if}
        </Table.Body>
      </Table.Root>
    </div>

    <!-- Pagination Footer -->
    <footer class="flex h-12 items-center justify-between border-t border-slate-100 px-6">
      <div class="text-[12px] text-slate-500">
        Hiển thị 1 đến {natureReserves.length} trong số {natureReserves.length} mục
      </div>
      <div class="flex items-center gap-6">
        <div class="flex items-center gap-2">
          <span class="text-[12px] text-slate-500">Số bản ghi:</span>
          <div class="flex cursor-pointer items-center gap-2 rounded border border-slate-200 px-2 py-0.5 text-[12px] text-slate-700 hover:bg-slate-50">
            <span>{natureReserves.length} / trang</span>
            <ChevronDown class="size-3 text-slate-400" />
          </div>
        </div>
        <Pagination.Root count={natureReserves.length} perPage={10}>
        {#snippet children({ pages, currentPage })}
          <Pagination.Content>
            <Pagination.Item>
              <Pagination.PrevButton />
            </Pagination.Item>
            {#each pages as page (page.key)}
              {#if page.type === "ellipsis"}
                <Pagination.Item>
                  <Pagination.Ellipsis />
                </Pagination.Item>
              {:else}
                <Pagination.Item isVisible={true}>
                  <Pagination.Link {page} isActive={currentPage === page.value}>
                    {page.value}
                  </Pagination.Link>
                </Pagination.Item>
              {/if}
            {/each}
            <Pagination.Item>
              <Pagination.NextButton />
            </Pagination.Item>
          </Pagination.Content>
        {/snippet}
      </Pagination.Root>
      </div>
    </footer>
  </main>
</div>

<style>
  :global(body) {
    background-color: #f8fafc;
  }
</style>
