<script lang="ts">
  import * as Sidebar from "./ui/sidebar/index.js";
  import * as Table from "./ui/table/index.js";
  import {
    LayoutDashboard,
    Activity,
    Users,
    Package,
    FileText,
    Settings,
    Zap,
    TrendingUp,
    TrendingDown,
    Search,
    Download,
    Share2,
    RefreshCw,
    Calendar,
    SlidersHorizontal,
    X,
  } from "@lucide/svelte";
  import { cn } from "../lib/utils.js";

  type NavItemName =
    | "Overview"
    | "Analytics"
    | "Customers"
    | "Products"
    | "Reports"
    | "Settings";

  // State using Runes
  let activeNav = $state<NavItemName>("Overview");
  let showBanner = $state(true);
  let searchValue = $state("");

  const navItems: { name: NavItemName; icon: any }[] = [
    { name: "Overview", icon: LayoutDashboard },
    { name: "Analytics", icon: Activity },
    { name: "Customers", icon: Users },
    { name: "Products", icon: Package },
    { name: "Reports", icon: FileText },
    { name: "Settings", icon: Settings },
  ];

  const metrics = [
    {
      id: 1,
      label: "Total Revenue",
      value: "$284,590",
      change: "+12.5% from last month",
      trend: "up",
    },
    {
      id: 2,
      label: "Active Users",
      value: "12,847",
      change: "+8.2% from last month",
      trend: "up",
    },
    {
      id: 3,
      label: "Conversion Rate",
      value: "3.24%",
      change: "-2.1% from last month",
      trend: "down",
    },
    {
      id: 4,
      label: "Avg. Order Value",
      value: "$127.40",
      change: "+4.8% from last month",
      trend: "up",
    },
  ];

  const transactions = [
    {
      id: 101,
      name: "Premium Subscription",
      category: "Services",
      amount: "+$599.00",
      date: "Jan 5, 2026",
      status: "Completed",
    },
    {
      id: 102,
      name: "Luxury Bundle",
      category: "Products",
      amount: "+$1,250.00",
      date: "Jan 4, 2026",
      status: "Completed",
    },
    {
      id: 103,
      name: "Custom Implementation",
      category: "Services",
      amount: "+$24,500.00",
      date: "Jan 3, 2026",
      status: "Pending",
    },
  ];

  const chartBars: number[] = [80, 130, 65, 150, 100, 55, 40];
  const chartLabels: string[] = [
    "Mon",
    "Tue",
    "Wed",
    "Thu",
    "Fri",
    "Sat",
    "Sun",
  ];

  // Button style helpers matching Pencil/shadcn-svelte defaults
  const btnBase =
    "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium whitespace-nowrap transition-all outline-none disabled:pointer-events-none disabled:opacity-50";
  const btnOutline = `${btnBase} border border-[#2A2A2A] bg-transparent text-white hover:bg-[#141414]`;
  const btnGold = `${btnBase} bg-[#C9A962] text-[#0A0A0A] border-none hover:bg-[#B89851] font-semibold`;
</script>

<div
  class="luxury-theme font-inter min-h-screen bg-[#0A0A0A] text-white overflow-hidden"
>
  <Sidebar.Provider>
    <div class="flex h-screen w-full overflow-hidden">
      <!-- Sidebar -->
      <Sidebar.Root
        class="w-[280px] bg-[#0D0D0D] border-r border-[#2A2A2A] p-10 flex flex-col justify-between h-full shrink-0"
      >
        <div class="space-y-12 w-full flex flex-col">
          <!-- Logo -->
          <div class="flex items-center gap-3">
            <div
              class="w-9 h-9 border border-[#C9A962] rounded-none flex items-center justify-center font-cormorant font-semibold text-[18px] text-[#C9A962]"
            >
              A
            </div>
            <span class="text-[14px] font-medium tracking-[0.2em] text-white"
              >ACME</span
            >
          </div>

          <!-- Nav -->
          <Sidebar.Menu>
            {#each navItems as item}
              <Sidebar.MenuItem>
                <Sidebar.MenuButton
                  isActive={activeNav === item.name}
                  onclick={() => {
                    activeNav = item.name;
                  }}
                >
                  {@const Icon = item.icon}
                  <Icon
                    size={18}
                    class={activeNav === item.name
                      ? "text-[#C9A962]"
                      : "text-[#4A4A4A]"}
                  />
                  <span>{item.name}</span>
                </Sidebar.MenuButton>
              </Sidebar.MenuItem>
            {/each}
          </Sidebar.Menu>
        </div>

        <div class="space-y-6 w-full flex flex-col">
          <!-- Upgrade Banner -->
          <div class="p-5 border border-[#C9A96240] space-y-4">
            <h3 class="font-cormorant text-[18px] font-medium">
              Upgrade to Pro
            </h3>
            <p class="text-[12px] text-[#6A6A6A] leading-relaxed w-[180px]">
              Unlock premium features and advanced analytics.
            </p>
            <button
              class={btnGold + " w-full py-3 text-[12px]"}
              onclick={() => alert("Upgrade to Pro clicked!")}
            >
              <Zap size={14} />
              Upgrade Now
            </button>
          </div>

          <!-- User -->
          <div class="pt-4 border-t border-[#1A1A1A] flex items-center gap-3">
            <div
              class="w-10 h-10 border border-[#C9A962] flex items-center justify-center shrink-0"
            >
              <span class="text-[#C9A962] text-[12px] font-semibold">MR</span>
            </div>
            <div class="flex flex-col min-w-0">
              <span class="text-[13px] font-medium truncate"
                >Marcus Reynolds</span
              >
              <span class="text-[11px] text-[#6A6A6A] truncate"
                >m.reynolds@company.com</span
              >
            </div>
          </div>
        </div>
      </Sidebar.Root>

      <!-- Main Content -->
      <Sidebar.Inset class="flex-1 overflow-auto bg-[#0A0A0A] flex flex-col">
        <!-- Header -->
        <div
          class="p-12 pb-8 space-y-8 sticky top-0 bg-[#0A0A0A] z-20 shrink-0"
        >
          <div class="flex items-center justify-between">
            <!-- Breadcrumbs -->
            <div class="flex items-center gap-3 text-[12px]">
              <span class="text-[#4A4A4A]">Dashboard</span>
              <span class="text-[#2A2A2A]">/</span>
              <span class="text-[#4A4A4A]">Analytics</span>
              <span class="text-[#2A2A2A]">/</span>
              <span class="text-[#C9A962] font-medium">Overview</span>
            </div>
            <!-- Search -->
            <div class="relative w-[220px]">
              <Search
                size={16}
                class="absolute left-4 top-1/2 -translate-y-1/2 text-[#4A4A4A]"
              />
              <input
                bind:value={searchValue}
                placeholder="Search insights..."
                class="w-full bg-transparent border border-[#2A2A2A] py-2.5 pl-11 pr-4 text-[12px] text-white outline-none focus:border-[#C9A962] transition-colors rounded-md"
              />
            </div>
          </div>

          <div class="flex items-end justify-between">
            <div class="space-y-3">
              <h2
                class="font-cormorant text-[48px] leading-tight tracking-tight"
              >
                Overview
              </h2>
              <p class="text-[#6A6A6A] text-[14px]">
                Track performance metrics and key business insights
              </p>
            </div>
            <div class="flex items-center gap-3">
              <button class={btnOutline + " px-5 py-2.5 text-[12px]"}
                >Secondary Action</button
              >
              <button class={btnGold + " px-5 py-2.5 text-[12px]"}
                >Primary Action</button
              >
            </div>
          </div>
        </div>

        <!-- Controls & Body -->
        <div class="px-14 pb-12 space-y-12 flex-1">
          <!-- QA Controls -->
          <div class="flex items-center gap-3">
            <button class={btnOutline + " text-[12px] px-4 py-2.5"}>
              <SlidersHorizontal size={14} class="text-[#6A6A6A]" />
              Filter
            </button>
            <button class={btnOutline + " text-[12px] px-4 py-2.5"}>
              <Calendar size={14} class="text-[#6A6A6A]" />
              Date Range
            </button>
            <button class={btnOutline + " text-[12px] px-4 py-2.5"}>
              <RefreshCw size={14} class="text-[#6A6A6A]" />
              Refresh
            </button>
            <button class={btnOutline + " text-[12px] px-4 py-2.5"}>
              <Share2 size={14} class="text-[#6A6A6A]" />
              Share
            </button>
          </div>

          <!-- Metrics -->
          <div class="grid grid-cols-1 md:grid-cols-4 gap-5">
            {#each metrics as metric, i}
              <div
                class="p-7 border border-[#2A2A2A] space-y-5 group hover:border-[#C9A96280] transition-all duration-500 hover:shadow-[0_0_20px_rgba(201,169,98,0.05)] bg-[#0D0D0D]/50"
              >
                <div class="flex items-center justify-between">
                  <span
                    class="text-[11px] font-semibold uppercase tracking-[0.1em] text-[#6A6A6A]"
                    >{metric.label}</span
                  >
                  <div
                    class={cn(
                      "w-1.5 h-1.5 rounded-full",
                      metric.trend === "up" ? "bg-[#C9A962]" : "bg-[#8B5A5A]",
                    )}
                  ></div>
                </div>
                <div
                  class="font-cormorant text-[40px] font-medium tracking-tight group-hover:text-[#C9A962] transition-colors duration-500"
                >
                  {metric.value}
                </div>
                <div class="flex items-center gap-2">
                  {#if metric.trend === "up"}
                    <TrendingUp size={14} class="text-[#C9A962]" />
                  {:else}
                    <TrendingDown size={14} class="text-[#8B5A5A]" />
                  {/if}
                  <span class="text-[12px] text-[#6A6A6A]">{metric.change}</span
                  >
                </div>
              </div>
            {/each}
          </div>

          <!-- Chart & List -->
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div
              class="lg:col-span-2 p-7 border border-[#2A2A2A] space-y-8 bg-[#0D0D0D]/30"
            >
              <div class="flex items-center justify-between">
                <div class="space-y-1">
                  <h3 class="font-cormorant text-[24px] font-medium">
                    Weekly Revenue
                  </h3>
                  <p
                    class="text-[11px] text-[#6A6A6A] uppercase tracking-widest"
                  >
                    Last 7 days
                  </p>
                </div>
              </div>
              <!-- Custom SVG Bar Chart -->
              <div
                class="h-[180px] w-full border-b border-[#2A2A2A] flex items-end justify-between px-4 pb-4 gap-4 overflow-hidden"
              >
                {#each chartBars as val, idx}
                  <div
                    class="flex-1 flex flex-col items-center gap-3 h-full justify-end group/bar"
                  >
                    <div
                      class="w-full bg-[#C9A962] opacity-60 group-hover/bar:opacity-100 transition-all duration-700 ease-out"
                      style="height: {(val / 200) * 100}%;"
                    ></div>
                    <span
                      class="text-[10px] font-medium text-[#4A4A4A] tracking-wider"
                      >{chartLabels[idx]}</span
                    >
                  </div>
                {/each}
              </div>
            </div>

            <!-- ListSection -->
            <div class="space-y-6">
              <div class="flex items-center justify-between">
                <h3 class="font-cormorant text-[24px] font-medium">
                  Recent Transactions
                </h3>
                <span
                  class="text-[12px] font-medium text-[#C9A962] cursor-pointer hover:underline"
                  >View all →</span
                >
              </div>
              <div class="border border-[#2A2A2A] divide-y divide-[#1A1A1A]">
                {#each transactions as tx}
                  <div
                    class="p-6 flex items-center justify-between hover:bg-[#141414] transition-colors"
                  >
                    <div class="flex items-center gap-4">
                      <div
                        class="w-10 h-10 bg-[#141414] border border-[#2A2A2A] flex items-center justify-center"
                      >
                        <Zap size={16} class="text-[#C9A962]" />
                      </div>
                      <div class="flex flex-col">
                        <span class="text-[13px] font-medium">{tx.name}</span>
                        <span class="text-[11px] text-[#6A6A6A]"
                          >{tx.category}</span
                        >
                      </div>
                    </div>
                    <div class="flex flex-col items-end gap-1">
                      <span class="text-[13px] font-medium text-[#C9A962]"
                        >{tx.amount}</span
                      >
                      <span class="text-[11px] text-[#6A6A6A]">{tx.date}</span>
                    </div>
                  </div>
                {/each}
              </div>
            </div>
          </div>

          <!-- Banner -->
          <div
            class="p-4 px-5 border border-[#C9A96230] flex items-center justify-between"
          >
            <div class="flex items-center gap-4">
              <div
                class="w-2 h-2 rounded-full bg-[#C9A962] shadow-[0_0_6px_rgba(201,169,98,0.4)]"
              ></div>
              <span class="text-[13px] text-[#8A8A8A]"
                >System maintenance scheduled for Jan 8, 2026 at 2:00 AM EST.
                Expect brief downtime.</span
              >
            </div>
            <X
              size={16}
              class="text-[#4A4A4A] cursor-pointer hover:text-white"
            />
          </div>

          <!-- Table Section -->
          <div class="space-y-6">
            <div class="flex items-center justify-between">
              <h3 class="font-cormorant text-[24px] font-medium">
                Customer Analytics
              </h3>
              <button
                variant="outline"
                class="flex items-center gap-2 px-4 py-2 border border-[#2A2A2A] bg-transparent text-white text-[12px] font-medium hover:bg-[#141414] transition-colors"
              >
                <Download size={14} class="text-[#6A6A6A]" />
                Export
              </button>
            </div>
            <div class="border border-[#2A2A2A] overflow-hidden">
              <Table.Root class="w-full text-left border-collapse">
                <Table.Header class="bg-[#111111] border-b border-[#2A2A2A]">
                  <Table.Row>
                    <Table.Head
                      class="p-4 px-6 text-[11px] font-bold uppercase tracking-widest text-[#4A4A4A]"
                      >Customer</Table.Head
                    >
                    <Table.Head
                      class="p-4 px-6 text-[11px] font-bold uppercase tracking-widest text-[#4A4A4A]"
                      >Revenue</Table.Head
                    >
                    <Table.Head
                      class="p-4 px-6 text-[11px] font-bold uppercase tracking-widest text-[#4A4A4A]"
                      >Plan</Table.Head
                    >
                    <Table.Head
                      class="p-4 px-6 text-[11px] font-bold uppercase tracking-widest text-[#4A4A4A]"
                      >Status</Table.Head
                    >
                  </Table.Row>
                </Table.Header>
                <Table.Body class="divide-y divide-[#1A1A1A]">
                  {#each [{ name: "Enzo Ferrari", revenue: "$12,400", plan: "Gold", status: "Active" }, { name: "Diana Prince", revenue: "$8,200", plan: "Silver", status: "Active" }, { name: "Albus D.", revenue: "$15,450", plan: "Gold", status: "Pending" }, { name: "Wayne Enterprises", revenue: "$42,500", plan: "Platinum", status: "Active" }] as customer}
                    <Table.Row
                      class="hover:bg-[#141414] transition-colors border-none group"
                    >
                      <Table.Cell class="p-4 px-6">
                        <div class="flex items-center gap-3">
                          <div class="w-2 h-2 rounded-none bg-[#C9A962]"></div>
                          <span class="text-[13px] font-medium"
                            >{customer.name}</span
                          >
                        </div>
                      </Table.Cell>
                      <Table.Cell
                        class="p-4 px-6 text-[13px] tabular-nums font-medium text-[#C9A962]"
                        >{customer.revenue}</Table.Cell
                      >
                      <Table.Cell class="p-4 px-6 text-[13px] text-[#8A8A8A]"
                        >{customer.plan}</Table.Cell
                      >
                      <Table.Cell class="p-4 px-6">
                        <badge
                          variant="outline"
                          class={cn(
                            "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 border rounded-none",
                            customer.status === "Active"
                              ? "border-[#C9A96240] text-[#C9A962]"
                              : "border-[#4A4A4A] text-[#6A6A6A]",
                          )}
                        >
                          {customer.status}
                        </badge>
                      </Table.Cell>
                    </Table.Row>
                  {/each}
                </Table.Body>
              </Table.Root>
            </div>
          </div>

          <!-- Gallery Section -->
          <div class="space-y-6">
            <div class="flex items-center justify-between">
              <h3 class="font-cormorant text-[24px] font-medium">
                Featured Products
              </h3>
              <div class="flex gap-1">
                <button
                  class="w-9 h-9 border border-[#2A2A2A] flex items-center justify-center hover:bg-[#141414] transition-colors text-[#6A6A6A]"
                  >←</button
                >
                <button
                  class="w-9 h-9 bg-[#C9A962] flex items-center justify-center hover:bg-[#B89851] transition-colors text-[#0A0A0A]"
                  >→</button
                >
              </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
              {#each [{ title: "The Obsidian Watch", price: "$2,450", img: "ai:minimalist luxury watch dark obsidian gold accents" }, { title: "Aether Fragrance", price: "$420", img: "ai:luxury perfume bottle dark sleek gold label" }, { title: "Elysium Handbag", price: "$3,800", img: "ai:luxury leather handbag dark minimalist gold hardware" }] as product}
                <div class="border border-[#2A2A2A] group overflow-hidden">
                  <div
                    class="aspect-video bg-[#141414] flex items-center justify-center relative border-b border-[#1A1A1A]"
                  >
                    <div
                      class="w-full h-full bg-gradient-to-tr from-black/20 to-transparent"
                    ></div>
                    <span
                      class="absolute inset-0 flex items-center justify-center text-[10px] text-[#2A2A2A] uppercase tracking-widest"
                      >Image Placeholder</span
                    >
                  </div>
                  <div class="p-5 space-y-2 border-t border-[#1A1A1A]">
                    <div
                      class="text-[14px] font-medium group-hover:text-[#C9A962] transition-colors"
                    >
                      {product.title}
                    </div>
                    <div
                      class="text-[12px] text-[#6A6A6A] font-cormorant tracking-widest"
                    >
                      {product.price}
                    </div>
                  </div>
                </div>
              {/each}
            </div>
          </div>
        </div>
      </Sidebar.Inset>
    </div>
  </Sidebar.Provider>
</div>

<style>
  @import url("https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap");

  :global(.font-cormorant) {
    font-family: "Cormorant Garamond", serif;
  }

  :global(.font-inter) {
    font-family: "Inter", sans-serif;
  }

  /* Luxury Theme Overrides */
  .luxury-theme :global(.bg-sidebar) {
    background-color: #0d0d0d;
  }

  .luxury-theme :global(.border-sidebar-border) {
    border-color: #2a2a2a;
  }

  ::-webkit-scrollbar {
    width: 6px;
  }

  ::-webkit-scrollbar-track {
    background: #0a0a0a;
  }

  ::-webkit-scrollbar-thumb {
    background: #1a1a1a;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #2a2a2a;
  }
</style>
