<script lang="ts">
  import { Badge } from "@/components/ui/badge/index.js";
  import { Button } from "@/components/ui/button/index.js";
  import * as Card from "@/components/ui/card/index.js";
  import { Input } from "@/components/ui/input/index.js";
  import { Label } from "@/components/ui/label/index.js";
  import { Textarea } from "@/components/ui/textarea/index.js";
  import * as Table from "@/components/ui/table/index.js";
  import * as Pagination from "@/components/ui/pagination/index.js";
  import { Plus, Bell, Send } from "lucide-svelte";
  import { client } from "@/utils/trpc";
  import { toast } from "svelte-sonner";
  import { Toaster } from "@/components/ui/sonner";

  // Reactive state for table data
  let tableData = $state<any[]>([]);
  let isLoading = $state(true);

  // Form state
  let formValues = $state({
    title: "",
    columnId: "c1",
    description: ""
  });
  let isSubmitting = $state(false);

  async function handleSubmit(e: SubmitEvent) {
    e.preventDefault();
    if (!formValues.title) return toast.error("Title is required");
    
    try {
      isSubmitting = true;
      const result = await client.s1.createTask.mutate(formValues);
      toast.success(`Task created: ${result.title}`);
      
      // Reset form
      formValues.title = "";
      formValues.description = "";
      
      // Refresh table/health (simulated)
      console.log("Task created result:", result);
    } catch (error) {
      console.error("Failed to create task:", error);
      toast.error("Failed to create task");
    } finally {
      isSubmitting = false;
    }
  }

  // Fetch data on mount
  $effect(() => {
    const fetchData = async () => {
      try {
        isLoading = true;
        const health = await client.s1.health.query();
        // Map health object to table row format
        tableData = [{
          id: "1",
          date: new Date(health.timestamp).toLocaleDateString(),
          type: "System Health",
          amount: health.service,
          status: health.status === "ok" ? "Completed" : "Error"
        }];
      } catch (error) {
        console.error("Failed to fetch health data:", error);
        tableData = [{
          id: "!",
          date: new Date().toLocaleDateString(),
          type: "Error",
          amount: "N/A",
          status: "Failed"
        }];
      } finally {
        isLoading = false;
      }
    };
    fetchData();
  });
</script>

<div class="flex h-full w-full flex-col gap-8 p-8">
  <!-- Header Section -->
  <div class="flex w-full items-center justify-between">
    <div class="flex items-center gap-4">
      <h1 class="text-3xl font-bold tracking-tight text-foreground">Usage Overview</h1>
      <Badge variant="default" class="rounded-full px-2 py-[2px] text-xs font-semibold">March 2024</Badge>
    </div>
    <div class="flex items-center gap-2">
      <Button variant="outline" size="icon" class="rounded-full">
        <Bell class="size-4" />
      </Button>
    </div>
  </div>

  <!-- Stats Grid -->
  <div class="grid w-full grid-cols-1 gap-6 md:grid-cols-3">
    <!-- Card 1 -->
    <Card.Root>
      <Card.Header class="pb-2">
        <Card.Title class="text-sm font-medium text-muted-foreground">Electricity Usage</Card.Title>
      </Card.Header>
      <Card.Content>
        <div class="text-2xl font-bold">425.8 kWh</div>
        <p class="text-xs text-muted-foreground">+5.2% from last month</p>
      </Card.Content>
    </Card.Root>

    <!-- Card 2 -->
    <Card.Root>
      <Card.Header class="pb-2">
        <Card.Title class="text-sm font-medium text-muted-foreground">Water Usage</Card.Title>
      </Card.Header>
      <Card.Content>
        <div class="text-2xl font-bold">1,240 gal</div>
        <p class="text-xs text-muted-foreground">-2.1% from last month</p>
      </Card.Content>
    </Card.Root>

    <!-- Card 3 -->
    <Card.Root>
      <Card.Header class="pb-2">
        <Card.Title class="text-sm font-medium text-muted-foreground">Gas Usage</Card.Title>
      </Card.Header>
      <Card.Content>
        <div class="text-2xl font-bold">12.4 therms</div>
        <p class="text-xs text-muted-foreground">+1.4% from last month</p>
      </Card.Content>
    </Card.Root>
  </div>

  <!-- Data Table Section -->
  <div class="flex w-full flex-col gap-4">
    <!-- Data Table Header -->
    <div class="flex w-full items-center justify-between">
      <Input type="text" placeholder="Filter emails..." class="max-w-sm" />
      <Button variant="outline">Columns</Button>
    </div>

    <!-- Data Table Content -->
    <div class="rounded-md border">
      <Table.Root>
        <Table.Header>
          <Table.Row>
            <Table.Head class="w-[100px]">ID</Table.Head>
            <Table.Head>Date</Table.Head>
            <Table.Head>Type</Table.Head>
            <Table.Head>Status</Table.Head>
            <Table.Head class="text-right">Amount</Table.Head>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {#if isLoading}
            <Table.Row>
              <Table.Cell colspan={5} class="text-center py-10 text-muted-foreground animate-pulse">
                Loading system data...
              </Table.Cell>
            </Table.Row>
          {:else}
            {#each tableData as row}
              <Table.Row>
                <Table.Cell class="font-medium">{row.id}</Table.Cell>
                <Table.Cell>{row.date}</Table.Cell>
                <Table.Cell>{row.type}</Table.Cell>
                <Table.Cell>{row.status}</Table.Cell>
                <Table.Cell class="text-right">{row.amount}</Table.Cell>
              </Table.Row>
            {/each}
          {/if}
        </Table.Body>
      </Table.Root>
    </div>

    <!-- Data Table Footer -->
    <div class="flex w-full items-center justify-between text-sm text-muted-foreground">
      <div>Showing 10 records</div>
      <Pagination.Root count={100} perPage={10}>
        {#snippet children({ pages, currentPage })}
          <Pagination.Content>
            <Pagination.Item>
              <Pagination.PrevButton />
            </Pagination.Item>
            {#each pages as page (page.key)}
              {#if page.type === "ellipsis"}
                <Pagination.Item>
                  <Pagination.Ellipsis />
                </Pagination.Item>
              {:else}
                <Pagination.Item isVisible={true}>
                  <Pagination.Link {page} isActive={currentPage === page.value}>
                    {page.value}
                  </Pagination.Link>
                </Pagination.Item>
              {/if}
            {/each}
            <Pagination.Item>
              <Pagination.NextButton />
            </Pagination.Item>
          </Pagination.Content>
        {/snippet}
      </Pagination.Root>
    </div>
  </div>

  <!-- Input Group Section (Now a Form) -->
  <form onsubmit={handleSubmit} class="flex flex-col gap-6">
    <div class="grid w-full grid-cols-1 gap-6 md:grid-cols-3">
      <div class="flex flex-col gap-1.5">
        <Label for="task-title" class="text-sm font-medium">Task Title</Label>
        <Input id="task-title" bind:value={formValues.title} placeholder="Enter task title..." />
      </div>
      <div class="flex flex-col gap-1.5">
        <Label for="task-column" class="text-sm font-medium">Column ID</Label>
        <Input id="task-column" bind:value={formValues.columnId} placeholder="c1" />
      </div>
      <div class="flex flex-col gap-1.5">
        <Label for="task-desc" class="text-sm font-medium">Description</Label>
        <Textarea id="task-desc" bind:value={formValues.description} placeholder="Optional description..." class="min-h-[40px]" />
      </div>
    </div>
    <div class="flex justify-end">
      <Button type="submit" disabled={isSubmitting} class="gap-2 bg-black text-white hover:bg-black/90">
        {#if isSubmitting}
          <span class="animate-spin">⏳</span>
        {:else}
          <Send class="size-4" />
        {/if}
        Create Task
      </Button>
    </div>
  </form>
</div>

<Toaster />
