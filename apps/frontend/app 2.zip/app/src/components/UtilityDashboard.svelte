<script lang="ts">
  import { 
    Sidebar, 
    SidebarContent, 
    SidebarGroup, 
    SidebarGroupContent, 
    SidebarMenu, 
    SidebarMenuItem, 
    SidebarMenuButton,
    SidebarProvider,
    SidebarInset,
    SidebarHeader,
    SidebarFooter 
  } from "./ui/sidebar/index.js";
  import { 
    Card, 
    CardContent, 
    CardHeader, 
    CardTitle 
  } from "./ui/card/index.js";
  import { 
    Table, 
    TableBody, 
    TableCell, 
    TableHead, 
    TableHeader, 
    TableRow 
  } from "./ui/table/index.js";
  import { 
    Avatar, 
    AvatarImage, 
    AvatarFallback 
  } from "./ui/avatar/index.js";
  import { Badge } from "./ui/badge/index.js";
  import { Progress } from "./ui/progress/index.js";
  import { 
    LayoutDashboard, 
    History, 
    TrendingUp, 
    Bell,
    ChevronDown,
    Zap
  } from "@lucide/svelte";

  // Svelte 5 Runes for reactive state
  let activeTab = $state("Dashboard");
  
  const currentUsage = $state([
    { id: 1, label: "Electricity Usage", value: "425.8", unit: "kWh", change: "+5.2%", progress: 65 },
    { id: 2, label: "Water Usage", value: "1,240", unit: "gal", change: "-2.1%", progress: 45 },
    { id: 3, label: "Gas Usage", value: "12.4", unit: "therms", change: "+1.4%", progress: 30 },
  ]);

  const usageHistory = $state([
    { id: 101, date: "March 15, 2024", type: "Electricity", amount: "12.5 kWh", status: "Paid" },
    { id: 102, date: "March 14, 2024", type: "Water", amount: "45 gal", status: "Pending" },
    { id: 103, date: "March 12, 2024", type: "Gas", amount: "0.8 therms", status: "Paid" },
  ]);

  const navItems = [
    { title: "Dashboard", icon: LayoutDashboard },
    { title: "Usage Stats", icon: TrendingUp },
    { title: "Bill History", icon: History },
    { title: "Notifications", icon: Bell },
  ];
</script>

<SidebarProvider>
  <div class="flex h-screen w-full bg-background overflow-hidden text-foreground">
    <Sidebar class="border-r border-sidebar-border bg-sidebar">
      <SidebarHeader class="p-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <div class="bg-primary p-2 rounded-lg flex items-center justify-center aspect-square h-8">
              <Zap class="text-primary-foreground h-4 w-4" />
            </div>
            <div class="flex flex-col">
              <span class="font-semibold text-sm leading-tight text-sidebar-foreground">Utilify</span>
            </div>
          </div>
          <ChevronDown class="h-4 w-4 text-muted-foreground" />
        </div>
      </SidebarHeader>
      
      <SidebarContent class="px-2">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {#each navItems as item}
                <SidebarMenuItem>
                  <SidebarMenuButton 
                    onclick={() => activeTab = item.title}
                    isActive={activeTab === item.title}
                  >
                    <item.icon class="h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              {/each}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter class="p-4 mt-auto">
        <div class="flex items-center justify-between bg-sidebar-accent/50 p-2 rounded-lg border border-sidebar-border/50">
          <div class="flex items-center gap-3 overflow-hidden">
            <Avatar class="h-8 w-8 rounded-lg shrink-0">
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback class="rounded-lg">JD</AvatarFallback>
            </Avatar>
            <div class="flex flex-col text-left overflow-hidden">
              <span class="text-xs font-semibold text-sidebar-foreground truncate">Jon Doe</span>
              <span class="text-[10px] text-muted-foreground truncate">joe@acmecorp.com</span>
            </div>
          </div>
          <ChevronDown class="h-3 w-3 text-muted-foreground shrink-0" />
        </div>
      </SidebarFooter>
    </Sidebar>

    <SidebarInset class="flex-1 flex flex-col overflow-auto bg-background">
      <header class="h-16 flex items-center justify-between px-8 bg-background border-b z-10 sticky top-0 shrink-0">
        <h1 class="text-2xl font-bold tracking-tight">Usage Overview</h1>
        <div class="flex items-center gap-3">
          <Badge variant="secondary" class="bg-secondary px-3 py-1 font-medium">March 2024</Badge>
          <button class="p-2 h-9 w-9 rounded-md border bg-background hover:bg-accent hover:text-accent-foreground transition-colors flex items-center justify-center relative">
            <Bell class="h-4 w-4" />
            <span class="absolute top-2 right-2 w-1.5 h-1.5 bg-primary rounded-full ring-2 ring-background"></span>
          </button>
        </div>
      </header>

      <main class="p-8 space-y-10 min-h-0 overflow-auto flex-1">
        <section>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            {#each currentUsage as stat}
              <Card class="border shadow-sm">
                <CardHeader class="pb-2">
                  <CardTitle class="text-[10px] font-bold text-muted-foreground tracking-widest uppercase">{stat.label}</CardTitle>
                </CardHeader>
                <CardContent class="space-y-4">
                  <div class="flex items-baseline gap-1">
                    <span class="text-3xl font-bold tabular-nums">{stat.value}</span>
                    <span class="text-sm font-medium text-muted-foreground">{stat.unit}</span>
                  </div>
                  <Progress value={stat.progress} class="h-1.5" />
                  <div class="flex items-center">
                    <Badge variant="outline" class="text-[10px] h-5 px-1.5 border-none bg-muted font-bold tracking-tight">
                      {stat.change}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            {/each}
          </div>
        </section>

        <section class="space-y-4">
          <h2 class="text-xl font-semibold tracking-tight">Usage History</h2>
          <Card class="border shadow-sm overflow-x-auto ring-1 ring-black/5">
            <Table>
              <TableHeader>
                <TableRow class="bg-muted/50 hover:bg-muted/50">
                  <TableHead class="text-xs font-bold uppercase tracking-wider">Date</TableHead>
                  <TableHead class="text-xs font-bold uppercase tracking-wider">Type</TableHead>
                  <TableHead class="text-xs font-bold uppercase tracking-wider">Amount</TableHead>
                  <TableHead class="text-right text-xs font-bold uppercase tracking-wider">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {#each usageHistory as record}
                  <TableRow class="hover:bg-accent/50 transition-colors">
                    <TableCell class="text-sm tabular-nums font-medium">{record.date}</TableCell>
                    <TableCell class="text-sm text-muted-foreground">{record.type}</TableCell>
                    <TableCell class="text-sm tabular-nums font-semibold">{record.amount}</TableCell>
                    <TableCell class="text-right">
                      <Badge 
                        variant={record.status === "Paid" ? "default" : "secondary"}
                        class="text-[10px] font-extrabold h-5 px-2 tracking-tighter"
                      >
                        {record.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                {/each}
              </TableBody>
            </Table>
          </Card>
        </section>
      </main>
    </SidebarInset>
  </div>
</SidebarProvider>

<style>
  :global(:root) {
    --sidebar-background: 0 0% 100%;
    --sidebar-foreground: 240 5.3% 26.1%;
    --sidebar-primary: 240 5.9% 10%;
    --sidebar-primary-foreground: 0 0% 98%;
    --sidebar-accent: 240 4.8% 95.9%;
    --sidebar-accent-foreground: 240 5.9% 10%;
    --sidebar-border: 240 5.9% 90%;
    --sidebar-ring: 217.2 91.2% 59.8%;
  }

  :global(body) {
    overflow: hidden;
  }
</style>
