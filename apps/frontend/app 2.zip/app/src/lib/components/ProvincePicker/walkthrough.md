# Walkthrough: ProvincePicker Component

Tài liệu này hướng dẫn chi tiết về Component `ProvincePicker` trong file `pencil-shadcn.pen`.

## 1. Thông tin chung
- **Node ID:** `e5Tr7`
- **Vị trí:** Đã được đưa vào **System Design Shadcn UI** (`MzSDs`) tại tọa độ `x: 2300, y: 100`.
- **Đặc điểm:** Thiết kế 1:1 theo ảnh mẫu, cưỡng bức Light Mode.

## 2. Thông số thiết kế chuẩn (Pixel Perfect)
- **Kích thước khung:** Rộng 400px (trong code Svelte đã chuyển sang `w-full`).
- **Màu sắc chính:**
  - Header Tab: `#2E6238` (Xanh lá đậm).
  - Background Active: `#FFFBE6` (Vàng nhạt).
  - Badge Background: `#E6F0FF` (Xanh dương nhạt).
  - Badge Text/Border: `#003366` (Xanh dương đậm).
  - Border chung: `#dddddd`.
- **Padding:**
  - Rows: `12px 16px`.
  - Checkbox: `20x20px` với corner radius `4px`.
  - Badge: `40x24px`.

## 3. Các trạng thái (States)
- **Default:** Nền trắng (`#FFFFFF`), Checkbox viền xám.
- **Selected:** Nền vàng nhạt (`#FFFBE6`), Checkbox xanh lá (`#2E6238`) với dấu tích trắng căn giữa.

## 4. Hướng dẫn sử dụng trong Svelte 5
Component tương ứng đã được khởi tạo tại:
`src/lib/components/ProvincePicker.svelte`

### Tính năng đã tích hợp:
- Tự động thay đổi màu nền khi tích chọn.
- Sử dụng Shadcn UI (Button, Checkbox, Badge) nhưng ghi đè style Tailwind để khớp thiết kế.
- Sử dụng `lucide-svelte` cho icon.

---
*Tài liệu này được tạo tự động bởi Gemini CLI.*
