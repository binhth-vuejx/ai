<script lang="ts">
	/**
	 * ProvincePicker.svelte - Svelte 5
	 * Fixed: Border color set to #dddddd for better visibility.
	 */
	import { Search, ChevronUp, ChevronLeft, ChevronRight, Check } from 'lucide-svelte';
	import { Button } from '$lib/components/ui/button';
	import { Checkbox } from '$lib/components/ui/checkbox';
	import { Badge } from '$lib/components/ui/badge';

	interface Province {
		id: string;
		name: string;
		count: number;
	}

	let { 
		provinces = [
			{ id: '1', name: 'Tỉnh An Giang', count: 4 },
			{ id: '2', name: 'Tỉnh Bắc Ninh', count: 1 },
			{ id: '3', name: 'Tỉnh Cà Mau', count: 0 },
			{ id: '4', name: 'Tỉnh Cao Bằng', count: 0 },
			{ id: '5', name: 'Tỉnh Đắk Lắk', count: 1 }
		],
		currentPage = 1,
		totalPages = 7
	} = $props<{
		provinces?: Province[];
		currentPage?: number;
		totalPages?: number;
	}>();

	// Quản lý các ID đang được chọn
	let selection = $state<Record<string, boolean>>({ '3': true, '4': true });

	function toggleProvince(id: string, checked: boolean | 'indeterminate') {
		selection[id] = checked === true;
	}
</script>

<div class="w-full text-black font-sans" style="color-scheme: light;">
	<div class="flex w-full flex-col overflow-hidden rounded-lg border border-[#dddddd] bg-white shadow-none p-0 m-0 gap-0">
		
		<!-- Header -->
		<div class="flex h-[52px] w-full items-end justify-between border-b-2 border-[#2E6238] bg-white pr-3 shrink-0 m-0 p-0">
			<div class="flex items-end shrink-0 p-0 m-0">
				<div class="flex h-[52px] items-center justify-center bg-[#2E6238] pl-4 pr-8 m-0">
					<span class="text-[18px] font-bold text-white leading-none">Tỉnh/Thành phố</span>
				</div>
				<svg width="20" height="52" viewBox="0 0 20 52" fill="none" class="shrink-0 -ml-[1px] block p-0 m-0">
					<path d="M0 0L20 52L0 52Z" fill="#2E6238"/>
				</svg>
			</div>

			<div class="flex pb-2 p-0 m-0">
				<Button variant="outline" size="icon" class="h-9 w-9 rounded-full border-[#dddddd] bg-white text-black shadow-none p-0 mr-2 shrink-0 hover:bg-gray-50">
					<Search size={20} strokeWidth={1.5} />
				</Button>
				<Button variant="outline" size="icon" class="h-9 w-9 rounded-full border-[#dddddd] bg-white text-black shadow-none p-0 shrink-0 hover:bg-gray-50">
					<ChevronUp size={20} strokeWidth={1.5} />
				</Button>
			</div>
		</div>

		<!-- List Container -->
		<div class="flex flex-col m-0 p-0 bg-white">
			{#each provinces as province}
				<div 
					class="flex items-center border-b border-[#dddddd] px-4 py-3 last:border-b-0 m-0 transition-all duration-200"
					style:background-color={selection[province.id] ? '#FFFBE6' : '#FFFFFF'}
				>
					<div class="relative flex items-center justify-center mr-3 shrink-0 p-0 m-0">
						<Checkbox 
							id={province.id} 
							checked={!!selection[province.id]}
							onCheckedChange={(v) => toggleProvince(province.id, v)}
							class="h-5 w-5 border-[#dddddd] bg-white data-[state=checked]:bg-[#2E6238] data-[state=checked]:border-[#2E6238] rounded shrink-0 m-0"
						/>
						{#if selection[province.id]}
							<div class="absolute pointer-events-none flex items-center justify-center m-0 p-0">
								<Check size={14} color="white" strokeWidth={3} />
							</div>
						{/if}
					</div>
					
					<label for={province.id} class="flex-grow text-[16px] font-normal text-black cursor-pointer select-none leading-tight m-0 p-0">
						{province.name}
					</label>
					
					<Badge variant="outline" class="flex h-6 w-10 shrink-0 items-center justify-center rounded border-[#003366] bg-[#E6F0FF] text-[14px] font-bold text-[#003366] p-0 shadow-none ml-3 m-0 hover:bg-[#E6F0FF]">
						{province.count}
					</Badge>
				</div>
			{/each}
		</div>

		<!-- Footer -->
		<div class="flex items-center justify-between p-3 border-t border-[#dddddd] bg-white shrink-0 m-0">
			<Button variant="outline" size="icon" class="h-9 w-9 rounded-full border-[#dddddd] bg-[#F5F5F5] text-black shadow-none p-0 shrink-0 hover:bg-gray-200">
				<ChevronLeft size={20} strokeWidth={1.5} />
			</Button>
			
			<span class="text-[16px] font-normal text-black m-0 p-0">Trang {currentPage}/{totalPages}</span>
			
			<Button variant="outline" size="icon" class="h-9 w-9 rounded-full border-[#dddddd] bg-[#F5F5F5] text-black shadow-none p-0 shrink-0 hover:bg-gray-200">
				<ChevronRight size={20} strokeWidth={1.5} />
			</Button>
		</div>
	</div>
</div>
